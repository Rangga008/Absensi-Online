<?php $__env->startSection('title', 'Concession Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">
            <i class="fas fa-file-medical-alt mr-2"></i>
            <?php if(session('role_id') == 3): ?>
                My Concessions
            <?php else: ?>
                Concession Management
            <?php endif; ?>
        </h1>
        

    </div>

    <div class="card shadow">
        <div class="card-header bg-primary text-white py-3">
            <h6 class="m-0 font-weight-bold">
                <i class="fas fa-list mr-2"></i>
                Concession List
            </h6>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle mr-2"></i>
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert">
                        <span>&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <!-- Filter Section -->
            <?php if(session('role_id') !== 3): ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="status_filter"><strong>Filter by Status:</strong></label>
                        <select class="form-control" id="status_filter" onchange="filterTable()">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="user_filter"><strong>Filter by Employee:</strong></label>
                        <select class="form-control" id="user_filter" onchange="filterTable()">
                            <option value="">All Employees</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="search"><strong>Search:</strong></label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" placeholder="Search by reason or employee..." onkeyup="filterTable()">
                            <div class="input-group-append">
                                <span class="input-group-text">
                                    <i class="fas fa-search"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="concessionsTable">
                    <thead class="bg-light">
                        <tr>
                            <th width="50">No</th>
                            <th>Employee</th>
                            <th>Reason</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th>Submitted At</th>
                            <?php if(session('role_id') !== 3): ?>
                            <th width="120">Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $concessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <?php if($concession->user->profile_photo_path): ?>
                                        <img src="<?php echo e(asset('storage/' . $concession->user->profile_photo_path)); ?>" 
                                             class="rounded-circle mr-2" 
                                             width="35" 
                                             height="35" 
                                             alt="<?php echo e($concession->user->name); ?>">
                                    <?php else: ?>
                                        <div class="avatar bg-primary text-white rounded-circle mr-2 d-flex align-items-center justify-content-center" 
                                             style="width: 35px; height: 35px;">
                                            <?php echo e(substr($concession->user->name, 0, 1)); ?>

                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <strong><?php echo e($concession->user->name); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($concession->user->email); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-info badge-pill py-1 px-2 mb-1">
                                    <?php echo e(ucfirst($concession->reason)); ?>

                                </span>
                                <?php if($concession->description): ?>
                                    <br>
                                    <small class="text-muted"><?php echo e(Str::limit($concession->description, 50)); ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($concession->start_date): ?>
                                    <span class="text-primary">
                                        <?php echo e($concession->start_date->locale('id')->isoFormat('D MMM YYYY')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($concession->end_date): ?>
                                    <span class="text-primary">
                                        <?php echo e($concession->end_date->locale('id')->isoFormat('D MMM YYYY')); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($concession->start_date && $concession->end_date): ?>
                                    <?php
                                        $duration = $concession->start_date->diffInDays($concession->end_date) + 1;
                                    ?>
                                    <span class="badge badge-secondary">
                                        <?php echo e($duration); ?> day<?php echo e($duration > 1 ? 's' : ''); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-pill py-2 px-3 badge-<?php echo e($concession->status == 'approved' ? 'success' : 
                                    ($concession->status == 'rejected' ? 'danger' : 'warning')); ?>">
                                    <i class="fas <?php echo e($concession->status == 'approved' ? 'fa-check' : 
                                        ($concession->status == 'rejected' ? 'fa-times' : 'fa-clock')); ?> mr-1"></i>
                                    <?php echo e(ucfirst($concession->status)); ?>

                                </span>
                            </td>
                            <td>
                                <small class="text-muted">
                                    <?php echo e($concession->created_at->locale('id')->isoFormat('D MMM YYYY HH:mm')); ?>

                                </small>
                            </td>
                            <?php if(session('role_id') !== 3): ?>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <a href="<?php echo e(route('admin.concessions.show', $concession->id)); ?>" 
                                       class="btn btn-info" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.concessions.edit', $concession->id)); ?>" 
                                       class="btn btn-primary" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.concessions.destroy', $concession->id)); ?>" 
                                          method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" 
                                                title="Delete"
                                                onclick="return confirm('Are you sure you want to delete this concession? This action cannot be undone.')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(session('role_id') !== 3 ? 9 : 8); ?>" class="text-center py-4">
                                <div class="text-muted">
                                    <i class="fas fa-file-medical-alt fa-3x mb-3"></i>
                                    <h5>No concessions found</h5>
                                    <p>No concession requests have been submitted yet.</p>
                                    
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if($concessions->hasPages()): ?>
            <div class="d-flex justify-content-between align-items-center mt-4">
                <div class="text-muted">
                    Showing <?php echo e($concessions->firstItem()); ?> to <?php echo e($concessions->lastItem()); ?> of <?php echo e($concessions->total()); ?> entries
                </div>
                <nav>
                    <?php echo e($concessions->links()); ?>

                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if(session('role_id') !== 3): ?>
<script>
function filterTable() {
    const statusFilter = document.getElementById('status_filter').value.toLowerCase();
    const userFilter = document.getElementById('user_filter').value;
    const searchFilter = document.getElementById('search').value.toLowerCase();
    
    const rows = document.querySelectorAll('#concessionsTable tbody tr');
    
    rows.forEach(row => {
        const status = row.cells[6].textContent.toLowerCase();
        const employeeId = row.cells[1].querySelector('strong').textContent.toLowerCase();
        const reason = row.cells[2].textContent.toLowerCase();
        const employeeEmail = row.cells[1].querySelector('small').textContent.toLowerCase();
        
        const statusMatch = statusFilter === '' || status.includes(statusFilter);
        const userMatch = userFilter === '' || row.getAttribute('data-user-id') === userFilter;
        const searchMatch = searchFilter === '' || 
                           reason.includes(searchFilter) || 
                           employeeId.includes(searchFilter) ||
                           employeeEmail.includes(searchFilter);
        
        row.style.display = statusMatch && userMatch && searchMatch ? '' : 'none';
    });
}

// Add user ID to each row for filtering
document.addEventListener('DOMContentLoaded', function() {
    const rows = document.querySelectorAll('#concessionsTable tbody tr');
    <?php $__currentLoopData = $concessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        rows[<?php echo e($loop->index); ?>].setAttribute('data-user-id', '<?php echo e($concession->user_id); ?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
});
</script>
<?php endif; ?>

<style>
.avatar {
    font-weight: bold;
    font-size: 14px;
}
.badge {
    font-size: 0.85em;
}
.table th {
    border-top: none;
    font-weight: 600;
    color: #495057;
}
.card-header {
    border-bottom: 1px solid #e3e6f0;
}
.btn-group .btn {
    border-radius: 4px;
    margin: 0 2px;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/concession/index.blade.php ENDPATH**/ ?>