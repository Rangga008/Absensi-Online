<?php $__env->startSection('content'); ?>
<!-- Outer Row -->
<div class="row justify-content-center min-vh-100 align-items-center">
    <div class="card o-hidden border-0 shadow-lg my-5" style="width: 500px; border-radius: 20px;">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-5">
                        <!-- Back Button -->
                        <a href="/" class="btn btn-circle btn-light" style="position: absolute; top: 20px; left: 20px;">
                            <i class="fas fa-arrow-left text-success"></i>
                        </a>
                        
                        <div class="text-center">
                            <img src="<?php echo e(app_logo()); ?>" width="100" alt="SMKN 2 Bandung" class="mb-3">
                            <h1 class="h4 text-gray-900 mb-1"><?php echo e(strtoupper(setting('app_name', 'SMK NEGERI 2 BANDUNG'))); ?></h1>
                            <h2 class="h5 text-success mb-4"><?php echo e(strtoupper(setting('company_name', 'SMK NEGERI 2 BANDUNG'))); ?></h2>
                            
                            <!-- Live Clock -->
                            <div class="mb-4">
                                <div class="clock h5 text-success" id="clock"></div>
                                <div class="date small text-muted" id="date"></div>
                            </div>
                            
                            <?php if(session()->has('message')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo e(session('message')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <form class="user" method="POST" action="<?php echo e(route('admin.login.process')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-text bg-transparent border-right-0"><i class="fas fa-envelope text-success"></i></span>
                                    <input type="email" class="form-control form-control-user" name="email" placeholder="Email" style="border-radius: 0 50px 50px 0;">
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger ml-3"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <span class="input-group-text bg-transparent border-right-0"><i class="fas fa-lock text-success"></i></span>
                                    <input type="password" class="form-control form-control-user" name="password" placeholder="Password" style="border-radius: 0 50px 50px 0;">
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger ml-3"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-success btn-user btn-block" style="border-radius: 50px;">
                                <i class="fas fa-sign-in-alt mr-2"></i> Login
                            </button>
                        </form>
                        <hr>
                        
                        <div class="text-center mt-2">
                            <p class="small text-muted">
                                <i class="fas fa-map-marker-alt mr-1"></i>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function updateTime() {
        const now = new Date();
        
        // Format time
        const timeOptions = {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        };
        const timeString = now.toLocaleTimeString('id-ID', timeOptions);
        
        // Format date
        const dateOptions = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        const dateString = now.toLocaleDateString('id-ID', dateOptions);
        
        document.getElementById('clock').textContent = timeString;
        document.getElementById('date').textContent = dateString;
    }
    
    // Update time immediately and then every second
    updateTime();
    setInterval(updateTime, 1000);
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/auth/login.blade.php ENDPATH**/ ?>