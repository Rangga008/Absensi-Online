

<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">User Management</h1>

<div class="card shadow mb-4">
    <div class="card-body">
        <?php echo $__env->make('admin.user.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="d-flex justify-content-between mb-3">
            <div></div> <!-- Empty div to maintain flex spacing -->

            <div>
                <a href="<?php echo e(route('admin.users.import.form')); ?>" class="btn btn-primary mr-2">
                    <i class="fas fa-file-import mr-1"></i> Import Users
                </a>
                <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">
                    <i class="fas fa-plus mr-1"></i> Add User
                </a>
            </div>
        </div>
        
        <div id="usersTableContainer">
            <?php echo $__env->make('admin.user.partials.table', ['users' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div id="paginationContainer" class="d-flex justify-content-center mt-3">
            <?php echo e($users->appends(request()->query())->links()); ?>

        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Search functionality removed - using global search from admin layout -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/user/index.blade.php ENDPATH**/ ?>