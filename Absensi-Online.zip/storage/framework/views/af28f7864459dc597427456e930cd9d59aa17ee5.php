

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-8">
            <div class="card shadow-lg border-0 rounded-lg">
                <div class="card-header bg-gradient-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="fas fa-history mr-2"></i>Riwayat 7 Hari Terakhir
                        </h5>
                        <span class="badge badge-light">
                            <i class="fas fa-calendar-alt mr-1"></i>
                            <?php echo e(\Carbon\Carbon::now()->isoFormat('D MMM YYYY')); ?>

                        </span>
                    </div>
                </div>
                
                <div class="card-body">
                    <div class="welcome-section mb-4 p-3 bg-light rounded">
                        <div class="d-flex align-items-center">
                            <div class="avatar-circle bg-primary mr-3">
                                <i class="fas fa-user text-white"></i>
                            </div>
                            <div>
                                <h6 class="mb-0 text-primary">Hai, <strong><?php echo e(ucfirst(session('username'))); ?></strong></h6>
                                <small class="text-muted">Selamat datang di sistem absensi</small>
                            </div>
                        </div>
                    </div>

                    <?php if($histories->isEmpty()): ?>
                        <div class="text-center py-5">
                            <div class="empty-state">
                                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">Tidak ada riwayat</h5>
                                <p class="text-muted">Tidak ada riwayat kehadiran dalam 7 hari terakhir</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="timeline">
                            <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="timeline-item">
                                    <div class="timeline-marker">
                                        <?php if($history->type === 'hadir'): ?>
                                            <div class="timeline-icon bg-success">
                                                <i class="fas fa-check"></i>
                                            </div>
                                        <?php else: ?>
                                            
                                            <?php if(isset($history->status) && $history->status === 'approved'): ?>
                                                <div class="timeline-icon bg-success">
                                                    <i class="fas fa-check"></i>
                                                </div>
                                            <?php elseif(isset($history->status) && $history->status === 'rejected'): ?>
                                                <div class="timeline-icon bg-danger">
                                                    <i class="fas fa-times"></i>
                                                </div>
                                            <?php else: ?>
                                                <div class="timeline-icon bg-warning">
                                                    <i class="fas fa-clock"></i>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="timeline-content card shadow-sm">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                <h6 class="mb-0 font-weight-bold">
                                                    <?php if($history->type === 'hadir'): ?>
                                                        Hadir
                                                    <?php else: ?>
                                                        <?php echo e(ucfirst($history->present_at)); ?>

                                                    <?php endif; ?>
                                                </h6>
                                                <span class="badge badge-<?php echo e($history->type === 'hadir' ? 'success' : 
                                                    (isset($history->status) && $history->status === 'approved' ? 'success' : 
                                                    (isset($history->status) && $history->status === 'rejected' ? 'danger' : 'warning'))); ?>">
                                                    <?php if($history->type === 'hadir'): ?>
                                                        Hadir
                                                    <?php else: ?>
                                                        <?php echo e(isset($history->status) ? 
                                                            ($history->status === 'approved' ? 'Disetujui' : 
                                                            ($history->status === 'rejected' ? 'Ditolak' : 'Menunggu')) : 
                                                            'Menunggu'); ?>

                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <small class="text-muted">
                                                        <i class="fas fa-calendar-day mr-1"></i>
                                                        <?php echo e($history->created_at->isoFormat('dddd, D MMMM YYYY')); ?>

                                                    </small>
                                                    <br>
                                                    <small class="text-muted">
                                                        <i class="fas fa-clock mr-1"></i>
                                                        <?php echo e($history->created_at->format('H:i')); ?> WIB
                                                    </small>
                                                </div>
                                                <div class="text-right">
                                                    <?php if($history->description): ?>
                                                        <button class="btn btn-sm btn-outline-primary" data-toggle="collapse"
                                                                data-target="#detail-<?php echo e($history->id); ?>" aria-expanded="false">
                                                            <i class="fas fa-info-circle"></i> Detail
                                                        </button>
                                                    <?php endif; ?>
                                                    <?php if($history->checkout_at): ?>
                                                        <button class="btn btn-sm btn-outline-success ml-1" data-toggle="collapse"
                                                                data-target="#checkout-detail-<?php echo e($history->id); ?>" aria-expanded="false">
                                                            <i class="fas fa-sign-out-alt"></i> Checkout
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            
                                            <?php if($history->description || $history->photo_path): ?>
                                                <div class="collapse mt-3" id="detail-<?php echo e($history->id); ?>">
                                                    <div class="detail-card p-3 bg-light rounded">
                                                        <?php if($history->description): ?>
                                                            <h6 class="text-primary mb-2">
                                                                <i class="fas fa-sticky-note mr-1"></i>Keterangan
                                                            </h6>
                                                            <p class="mb-0 text-dark"><?php echo e($history->description); ?></p>
                                                        <?php endif; ?>
                                                        <?php if($history->photo_path): ?>
                                                            <h6 class="text-primary mb-2 mt-3">
                                                                <i class="fas fa-camera mr-1"></i>Foto Absensi
                                                            </h6>
                                                            <img src="<?php echo e(asset('storage/' . $history->photo_path)); ?>" alt="Foto Absensi" class="img-fluid rounded" style="max-width: 200px;">
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php if($history->checkout_at): ?>
                                                <div class="collapse mt-3" id="checkout-detail-<?php echo e($history->id); ?>">
                                                    <div class="detail-card p-3 bg-light rounded">
                                                        <h6 class="text-primary mb-2">
                                                            <i class="fas fa-sign-out-alt mr-1"></i>Checkout
                                                        </h6>
                                                        <p class="mb-0 text-dark">
                                                            Waktu Checkout: <?php echo e($history->checkout_at->format('H:i')); ?> WIB<br>
                                                            Durasi Kerja: <?php echo e($history->work_duration_formatted ?: '0 jam 0 menit'); ?><br>
                                                            Jarak Checkout: <?php echo e($history->checkout_distance ? round($history->checkout_distance) : '-'); ?> meter
                                                        </p>
                                                        <?php if($history->checkout_photo_path): ?>
                                                            <img src="<?php echo e(asset('storage/' . $history->checkout_photo_path)); ?>" alt="Foto Checkout" class="img-fluid rounded mt-2" style="max-width: 200px;">
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="mt-4 text-center">
                        <a href="<?php echo e(url('user/home')); ?>" class="btn btn-primary btn-lg">
                            <i class="fas fa-arrow-left mr-2"></i> Kembali ke Beranda
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .bg-gradient-primary {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%) !important;
    }
    
    .avatar-circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }
    
    .welcome-section {
        background-color: #f8f9fc !important;
        border-left: 4px solid #4e73df;
    }
    
    .timeline {
        position: relative;
        padding-left: 3rem;
    }
    
    .timeline:before {
        content: '';
        position: absolute;
        left: 15px;
        top: 0;
        bottom: 0;
        width: 2px;
        background-color: #e3e6f0;
    }
    
    .timeline-item {
        position: relative;
        margin-bottom: 1.5rem;
    }
    
    .timeline-marker {
        position: absolute;
        left: -3rem;
        top: 0;
        z-index: 2;
    }
    
    .timeline-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 0.8rem;
        box-shadow: 0 0 0 4px white, 0 2px 5px rgba(0,0,0,0.15);
    }
    
    .timeline-content {
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        border-radius: 0.5rem;
        overflow: hidden;
    }
    
    .timeline-content:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1) !important;
    }
    
    .detail-card {
        border-left: 3px solid #4e73df;
    }
    
    .empty-state {
        opacity: 0.7;
    }
    
    @media (max-width: 768px) {
        .timeline {
            padding-left: 2.5rem;
        }
        
        .timeline-marker {
            left: -2.5rem;
        }
        
        .card-header h5 {
            font-size: 1.1rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        // Animasi untuk timeline items
        $('.timeline-item').each(function(i) {
            $(this).delay(i * 200).animate({ opacity: 1 }, 400);
        });
        
        // Tooltip untuk button detail
        $('[data-toggle="collapse"]').tooltip({
            title: "Klik untuk melihat detail",
            placement: "top"
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/user/history-attendance.blade.php ENDPATH**/ ?>