<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Laporan Absensi</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            line-height: 1.4;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .filters {
            margin-bottom: 20px;
            background: #f8f8f8;
            padding: 10px;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
        }
        .summary {
            margin-bottom: 20px;
            background: #e8f4f8;
            padding: 15px;
            border-radius: 5px;
        }
        .summary h3 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .summary p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
            $kopsuratPath = setting('kopsurat');
            $hasValidKopsurat = $kopsuratPath && File::exists(public_path($kopsuratPath));
        ?>

        <?php if($hasValidKopsurat): ?>
        <div style="text-align: center; margin-bottom: 20px;">
            <img src="data:image/jpeg;base64,<?php echo e(base64_encode(File::get(public_path($kopsuratPath)))); ?>"
                 alt="Kopsurat"
                 style="max-width: 100%; max-height: 120px; object-fit: contain;">
        </div>
        <?php endif; ?>

        <h1>Laporan Data Absensi</h1>
        <p><?php echo e(setting('company_name', 'Sekolah')); ?></p>
        <p>Dicetak pada: <?php echo e(now()->format('d F Y H:i:s')); ?></p>
        <?php if($startDate || $endDate): ?>
            <p>Periode: <?php echo e($startDate ?? 'Awal'); ?> s/d <?php echo e($endDate ?? 'Sekarang'); ?></p>
        <?php endif; ?>
    </div>

    <?php if($search || $roleFilter || $statusFilter): ?>
    <div class="filters">
        <strong>Filter yang diterapkan:</strong><br>
        <?php if($search): ?>
            <span>Pencarian: <?php echo e($search); ?></span><br>
        <?php endif; ?>
        <?php if($roleFilter && $roleFilter != 'all'): ?>
            <span>Role: <?php echo e($roleFilter); ?></span><br>
        <?php endif; ?>
        <?php if($statusFilter && $statusFilter != 'all'): ?>
            <span>Status: <?php echo e($statusFilter); ?></span><br>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="summary">
        <h3>Ringkasan Data</h3>
        <p>Total Record: <?php echo e($attendances->count()); ?></p>
        <?php
            $statusCount = $attendances->groupBy('description');
        ?>
        <?php $__currentLoopData = $statusCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $records): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($status); ?>: <?php echo e($records->count()); ?> record</p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Role</th>
                <th>Tanggal</th>
                <th>Waktu</th>
                <th>Status</th>
                <th>Status Checkout</th>
                <th>Waktu Checkout</th>
                <th>Durasi Kerja</th>
                <th>Jarak</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;"><?php echo e($index + 1); ?></td>
                <td><?php echo e($attendance->user->name ?? '-'); ?></td>
                <td><?php echo e($attendance->user->role->role_name ?? '-'); ?></td>
                <td><?php echo e($attendance->present_date); ?></td>
                <td><?php echo e($attendance->present_at ? $attendance->present_at->format('H:i:s') : '-'); ?></td>
                <td><?php echo e($attendance->description); ?></td>
                <td><?php echo e($attendance->hasCheckedOut() ? 'Sudah Keluar' : 'Belum Keluar'); ?></td>
                <td><?php echo e($attendance->checkout_at ? $attendance->checkout_at->format('H:i:s') : '-'); ?></td>
                <td><?php echo e($attendance->work_duration_formatted ?: '-'); ?></td>
                <td style="text-align: center;">
                    <?php if($attendance->distance): ?>
                        <?php echo e(number_format($attendance->distance)); ?> m
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        <p>Dokumen ini dihasilkan secara otomatis oleh Sistem Absensi Online</p>
        <p>&copy; <?php echo e(date('Y')); ?> - <?php echo e(setting('company_name', 'Sekolah')); ?></p>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/attendance/export_pdf.blade.php ENDPATH**/ ?>