<table class="table table-bordered" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Position</th>
            <?php if(isset($show_deleted) && $show_deleted): ?>
                <th>Deleted At</th>
            <?php endif; ?>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="<?php echo e(isset($show_deleted) && $show_deleted ? 'table-warning' : ''); ?>">
            <td>
                <?php echo e($user->name); ?>

                <?php if(isset($show_deleted) && $show_deleted): ?>
                    <span class="badge badge-warning ml-2">Deleted</span>
                <?php endif; ?>
            </td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->phone); ?></td>
            <td><?php echo e($user->role->role_name); ?></td>
            
            <?php if(isset($show_deleted) && $show_deleted): ?>
                <td><?php echo e($user->deleted_at->format('M d, Y H:i')); ?></td>
            <?php endif; ?>
            
            <td>
                <?php if(isset($show_deleted) && $show_deleted): ?>
                    <!-- Actions for deleted users -->
                    <form action="<?php echo e(route('admin.users.restore', $user->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" onclick="return confirm('Are you sure you want to restore this user?')" 
                                class="btn btn-success btn-sm" title="Restore">
                            <i class="fas fa-undo"></i> Restore
                        </button>
                    </form>
                    
                    <form action="<?php echo e(route('admin.users.force-delete', $user->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" 
                                onclick="return confirm('Are you sure you want to permanently delete this user? This action cannot be undone!')" 
                                class="btn btn-danger btn-sm" title="Permanently Delete">
                            <i class="fas fa-trash-alt"></i> Delete Permanently
                        </button>
                    </form>
                <?php else: ?>
                    <!-- Actions for active users -->
                    <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-info btn-sm" title="View">
                        <i class="fas fa-eye"></i>
                    </a>
                    <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-primary btn-sm" title="Edit">
                        <i class="fas fa-edit"></i>
                    </a>
                    <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('Are you sure? This will move the user to trash.')" 
                                class="btn btn-warning btn-sm" title="Move to Trash">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="<?php echo e(isset($show_deleted) && $show_deleted ? '6' : '5'); ?>" class="text-center">
                <?php if(request('search')): ?>
                <div class="py-4">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <h5>No users found matching "<?php echo e(request('search')); ?>"</h5>
                    <p class="text-muted">Try adjusting your search terms</p>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-primary">Clear Search</a>
                </div>
                <?php elseif(isset($show_deleted) && $show_deleted): ?>
                <div class="py-4">
                    <i class="fas fa-trash fa-3x text-muted mb-3"></i>
                    <h5>No deleted users found</h5>
                    <p class="text-muted">All users are currently active</p>
                    <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-primary">View Active Users</a>
                </div>
                <?php else: ?>
                <div class="py-4">
                    <i class="fas fa-users fa-3x text-muted mb-3"></i>
                    <h5>No users found</h5>
                    <p class="text-muted">Get started by adding a new user</p>
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">
                        <i class="fas fa-plus mr-1"></i> Add User
                    </a>
                </div>
                <?php endif; ?>
            </td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Filter buttons -->
<div class="d-flex justify-content-between align-items-center mt-3">
    <div class="btn-group" role="group" aria-label="User filters">
        <a href="<?php echo e(route('admin.users.index')); ?>" 
           class="btn btn-outline-primary <?php echo e(!request('show_deleted') ? 'active' : ''); ?>">
            <i class="fas fa-users"></i> Active Users
        </a>
        <a href="<?php echo e(route('admin.users.index', ['show_deleted' => 1])); ?>" 
           class="btn btn-outline-warning <?php echo e(request('show_deleted') ? 'active' : ''); ?>">
            <i class="fas fa-trash"></i> Deleted Users
        </a>
    </div>
    
    <?php if(isset($show_deleted) && $show_deleted && $users->total() > 0): ?>
    <div>
        <form action="<?php echo e(route('admin.users.restore-all')); ?>" method="POST" class="d-inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button type="submit" 
                    onclick="return confirm('Are you sure you want to restore all deleted users?')" 
                    class="btn btn-success">
                <i class="fas fa-undo"></i> Restore All
            </button>
        </form>
    </div>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/user/partials/table.blade.php ENDPATH**/ ?>