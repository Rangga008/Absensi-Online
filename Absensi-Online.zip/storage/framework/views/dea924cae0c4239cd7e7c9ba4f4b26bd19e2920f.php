<table class="table table-bordered" width="100%" cellspacing="0">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Position</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->phone); ?></td>
            <td><?php echo e($user->role->role_name); ?></td>
            <td>
                <a href="<?php echo e(route('admin.users.show', $user->id)); ?>" class="btn btn-info btn-sm" title="View">
                    <i class="fas fa-eye"></i>
                </a>
                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-primary btn-sm" title="Edit">
                    <i class="fas fa-edit"></i>
                </a>
                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" onclick="return confirm('Are you sure?')" 
                            class="btn btn-danger btn-sm" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="5" class="text-center">
        <?php if(request('search')): ?>
        <div class="py-4">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <h5>No users found matching "<?php echo e(request('search')); ?>"</h5>
            <p class="text-muted">Try adjusting your search terms</p>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline-primary">Clear Search</a>
        </div>
        <?php else: ?>
        <div class="py-4">
            <i class="fas fa-users fa-3x text-muted mb-3"></i>
            <h5>No users found</h5>
            <p class="text-muted">Get started by adding a new user</p>
            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus mr-1"></i> Add User
            </a>
        </div>
        <?php endif; ?>
    </td>
</tr>
<?php endif; ?>
    </tbody>
</table><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/user/partials/table.blade.php ENDPATH**/ ?>