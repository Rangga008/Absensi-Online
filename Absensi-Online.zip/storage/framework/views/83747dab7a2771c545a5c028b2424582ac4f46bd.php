

<?php $__env->startSection('title', 'Attendance Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h3 class="card-title">Attendance Details</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(url('admin/users/' . $attendance->user_id . '/attendances')); ?>" class="btn btn-primary">
                            <i class="fas fa-arrow-left"></i> Back
                        </a>
                    </div>
                </div>
                
                <div class="card-body">
                    <!-- Photo Section at the Top -->
                    <?php if($attendance->photo_path && Storage::disk('public')->exists($attendance->photo_path)): ?>
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header bg-info text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-camera mr-2"></i>Attendance Photo
                                    </h5>
                                </div>
                                <div class="card-body text-center">
                                    <?php
                                        $imageData = base64_encode(Storage::disk('public')->get($attendance->photo_path));
                                        $src = 'data:image/jpeg;base64,'.$imageData;
                                    ?>
                                    
                                    
                                    <div class="photo-container mb-3">
                                        <img src="<?php echo e($src); ?>" 
                                            alt="Attendance Photo" 
                                            class="img-fluid rounded shadow" 
                                            style="max-height: 500px; border: 1px solid #ddd;">
                                    </div>
                                    
                                    <div class="photo-actions">
                                        <button class="btn btn-primary btn-sm mr-2" onclick="window.open('<?php echo e($src); ?>', '_blank')">
                                            <i class="fas fa-expand mr-1"></i> Full View
                                        </button>
                                        <button class="btn btn-info btn-sm" onclick="downloadBase64Image('<?php echo e($src); ?>', 'attendance_photo_<?php echo e($attendance->id); ?>.jpg')">
                                            <i class="fas fa-download mr-1"></i> Download
                                        </button>
                                    </div>
                                    
                                    <div class="mt-2 text-muted small">
                                        <i class="fas fa-info-circle"></i> Photo taken at <?php echo e($attendance->present_at->format('H:i:s')); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-8">
                            <div class="card mb-4">
                                <div class="card-header bg-secondary text-white">
                                    <h4 class="card-title mb-0">Attendance Information</h4>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped">
                                            <tr>
                                                <th width="30%">User</th>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="avatar bg-primary text-white rounded-circle mr-2" 
                                                            style="width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;">
                                                            <?php echo e(substr($attendance->user->name, 0, 1)); ?>

                                                        </div>
                                                        <div>
                                                            <strong><?php echo e($attendance->user->name); ?></strong><br>
                                                            <small class="text-muted"><?php echo e($attendance->user->role->role_name ?? 'N/A'); ?></small>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <th>Date & Time</th>
                                                <td>
                                                    <?php echo e($attendance->present_at->translatedFormat('l, d F Y')); ?><br>
                                                    <span class="text-muted"><?php echo e($attendance->present_at->format('H:i:s')); ?></span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Status</th>
                                                <td>
                                                    <?php
                                                        $badgeClass = [
                                                            'Hadir' => 'success',
                                                            'Terlambat' => 'warning',
                                                            'Sakit' => 'info',
                                                            'Izin' => 'secondary',
                                                            'Dinas Luar' => 'primary',
                                                            'WFH' => 'dark'
                                                        ][$attendance->description] ?? 'light';
                                                    ?>
                                                    <span class="badge badge-<?php echo e($badgeClass); ?> badge-pill py-2 px-3">
                                                        <i class="fas <?php switch($attendance->description):
                                                            case ('Hadir'): ?> fa-check-circle <?php break; ?>
                                                            <?php case ('Terlambat'): ?> fa-clock <?php break; ?>
                                                            <?php case ('Sakit'): ?> fa-procedures <?php break; ?>
                                                            <?php case ('Izin'): ?> fa-envelope <?php break; ?>
                                                            <?php case ('Dinas Luar'): ?> fa-briefcase <?php break; ?>
                                                            <?php case ('WFH'): ?> fa-home <?php break; ?>
                                                        <?php endswitch; ?> mr-1"></i>
                                                        <?php echo e($attendance->description); ?>

                                                    </span>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Location</th>
                                                <td>
                                                    <div class="d-flex justify-content-between">
                                                        <div>
                                                            <strong>Coordinates:</strong><br>
                                                            <small class="text-muted">Lat:</small> <?php echo e(number_format($attendance->latitude, 6) ?? 'N/A'); ?><br>
                                                            <small class="text-muted">Lng:</small> <?php echo e(number_format($attendance->longitude, 6) ?? 'N/A'); ?>

                                                        </div>
                                                        <div class="text-right">
                                                            <strong>Distance:</strong><br>
                                                            <?php
                                                                $maxDistance = setting('max_distance', 500);
                                                                $companyName = setting('company_name', 'sekolah');
                                                            ?>
                                                            <?php if($attendance->distance): ?>
                                                                <?php if($attendance->distance <= $maxDistance): ?>
                                                                    <span class="badge badge-success">
                                                                        <?php echo e($attendance->distance); ?> meters
                                                                    </span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-danger">
                                                                        <?php echo e($attendance->distance); ?> meters
                                                                    </span>
                                                                    <div class="text-danger small mt-1">
                                                                        (Outside <?php echo e($maxDistance); ?>m radius from <?php echo e($companyName); ?>)
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                N/A
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th>Device Information</th>
                                                <td>
                                                    <div class="mb-2">
                                                        <strong>IP Address:</strong><br>
                                                        <code><?php echo e($attendance->ip_address ?? 'N/A'); ?></code>
                                                    </div>
                                                    <div>
                                                        <strong>User Agent:</strong><br>
                                                        <small class="text-muted"><?php echo e($attendance->user_agent ?? 'N/A'); ?></small>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header bg-success text-white">
                                    <h4 class="card-title mb-0">
                                        <i class="fas fa-map-marked-alt mr-2"></i>Location Map
                                    </h4>
                                </div>
                                <div class="card-body p-0">
                                    <?php if($attendance->latitude && $attendance->longitude): ?>
                                        <div id="map" style="height: 400px; width: 100%;"></div>
                                        <div class="p-3 border-top">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <span class="badge badge-danger mr-2">●</span>
                                                    <small><?php echo e(setting('company_name', 'SMKN 2 Bandung')); ?></small>
                                                </div>
                                                <div>
                                                    <span class="badge badge-primary mr-2">●</span>
                                                    <small>Attendance Location</small>
                                                </div>
                                                <a href="https://www.google.com/maps?q=<?php echo e($attendance->latitude); ?>,<?php echo e($attendance->longitude); ?>" 
                                                target="_blank" 
                                                class="btn btn-sm btn-outline-success">
                                                    <i class="fas fa-external-link-alt mr-1"></i> Google Maps
                                                </a>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-warning m-3">
                                            <i class="fas fa-exclamation-triangle mr-2"></i>
                                            No location data available for this attendance
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="card">
                                <div class="card-header bg-warning text-dark">
                                    <h4 class="card-title mb-0">
                                        <i class="fas fa-history mr-2"></i>Recent Activities
                                    </h4>
                                </div>
                                <div class="card-body">
                                    <?php if($recentAttendances->count() > 0): ?>
                                        <ul class="list-group list-group-flush">
                                            <?php $__currentLoopData = $recentAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-0">
                                                    <div>
                                                        <small class="text-muted"><?php echo e($recent->present_at->format('d M')); ?></small><br>
                                                        <strong><?php echo e($recent->description); ?></strong>
                                                    </div>
                                                    <span class="badge badge-light">
                                                        <?php echo e($recent->present_at->format('H:i')); ?>

                                                    </span>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <div class="text-center text-muted py-3">
                                            <i class="fas fa-info-circle fa-2x mb-2"></i>
                                            <p>No recent attendance records</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card-footer bg-light">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <a href="<?php echo e(route('admin.attendances.edit', $attendance->id)); ?>" 
                            class="btn btn-warning">
                                <i class="fas fa-edit mr-1"></i> Edit Record
                            </a>
                        </div>
                        <div>
                            <form action="<?php echo e(route('admin.attendances.destroy', $attendance->id)); ?>" 
                                method="POST" 
                                onsubmit="return confirm('Are you sure you want to delete this attendance record? This action cannot be undone.')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash-alt mr-1"></i> Delete
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if($attendance->latitude && $attendance->longitude): ?>
<!-- Leaflet CSS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Get office coordinates from settings
        const officeLat = <?php echo e(setting('office_lat', -6.906000)); ?>;
        const officeLng = <?php echo e(setting('office_lng', 107.623400)); ?>;
        const maxDistance = <?php echo e(setting('max_distance', 500)); ?>;
        const companyName = "<?php echo e(setting('company_name', 'SMKN 2 Bandung')); ?>";
        
        const attendanceLat = <?php echo e($attendance->latitude); ?>;
        const attendanceLng = <?php echo e($attendance->longitude); ?>;
        
        // Initialize map
        const map = L.map('map').setView([
            (officeLat + attendanceLat) / 2,
            (officeLng + attendanceLng) / 2
        ], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Office marker with custom icon
        const officeIcon = L.divIcon({
            html: '<div style="background-color: #e63946; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white;"><i class="fas fa-building"></i></div>',
            iconSize: [24, 24],
            className: 'custom-div-icon'
        });
        
        const officeMarker = L.marker([officeLat, officeLng], {
            icon: officeIcon
        }).addTo(map).bindPopup(`
            <b>${companyName}</b><br>
            <small>Office Location</small>
        `);

        // Attendance location marker with custom icon
        const userIcon = L.divIcon({
            html: '<div style="background-color: #007bff; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; color: white;"><i class="fas fa-user"></i></div>',
            iconSize: [24, 24],
            className: 'custom-div-icon'
        });
        
        const userMarker = L.marker([attendanceLat, attendanceLng], {
            icon: userIcon
        }).addTo(map).bindPopup(`
            <b>Attendance Location</b><br>
            <small>Recorded at <?php echo e($attendance->present_at->format('H:i:s')); ?></small>
        `);

        // Add line connecting the two points
        const line = L.polyline([
            [officeLat, officeLng],
            [attendanceLat, attendanceLng]
        ], {
            color: '#6c757d',
            dashArray: '5, 5',
            weight: 2
        }).addTo(map);

        // Add radius circle using configured max distance
        const circle = L.circle([officeLat, officeLng], {
            color: '#28a745',
            fillColor: '#28a745',
            fillOpacity: 0.1,
            radius: maxDistance
        }).addTo(map).bindPopup(`Valid Attendance Radius (${maxDistance}m)`);

        // Add distance label
        const distance = <?php echo e($attendance->distance ?? 0); ?>;
        const midpoint = {
            lat: (officeLat + attendanceLat) / 2,
            lng: (officeLng + attendanceLng) / 2
        };
        
        L.marker(midpoint, {
            icon: L.divIcon({
                html: `<div style="background: white; padding: 2px 6px; border-radius: 10px; border: 1px solid #6c757d; font-weight: bold;">${distance}m</div>`,
                iconSize: [60, 20],
                className: 'distance-label'
            })
        }).addTo(map);
    });

    // Function to download base64 image
    function downloadBase64Image(base64, filename) {
        const link = document.createElement('a');
        link.href = base64;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
</script>

<style>
.custom-div-icon {
    background: transparent;
    border: none;
}
.distance-label {
    background: transparent;
    border: none;
    pointer-events: none;
}
.photo-container {
    transition: all 0.3s ease;
}
.photo-container:hover {
    transform: translateY(-2px);
}
.photo-actions {
    margin-top: 15px;
}
</style>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/attendance/show.blade.php ENDPATH**/ ?>