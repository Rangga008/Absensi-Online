<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <a href="<?php echo e(route('admin.concessions.index')); ?>" class="btn btn-primary">
            <i class="fas fa-arrow-left mr-1"></i> Kembali
        </a>
        <h1 class="h3 mb-0 text-gray-800">
            <i class="fas fa-calendar-minus mr-2"></i>Tambah concessions Baru
        </h1>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <h6 class="font-weight-bold">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Terjadi Kesalahan
                    </h6>
                    <ul class="mb-0 pl-3">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle mr-1"></i><?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <form id="concessionForm" method="POST" action="<?php echo e(route('admin.concessions.store')); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                <label for="user_id" class="font-weight-bold">
                    <i class="fas fa-user mr-1"></i>Pilih Pengguna
                </label>
                <select class="form-control select2 <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        name="user_id" 
                        id="user_id"
                        required>
                    <option value="" selected disabled>-- Pilih Pengguna --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->role && $user->role->id != 0): ?> 
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?> - <?php echo e($user->role->role_name); ?>

                            </option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

                <div class="form-group">
                    <label for="reason" class="font-weight-bold">
                        <i class="fas fa-exclamation-circle mr-1"></i>Alasan Tidak Hadir
                    </label>
                    <select class="form-control <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="reason" 
                            id="reason"
                            required>
                        <option value="" selected disabled>-- Pilih Alasan --</option>
                        <option value="sakit" <?php echo e(old('reason') == 'sakit' ? 'selected' : ''); ?>>Sakit</option>
                        <option value="izin" <?php echo e(old('reason') == 'izin' ? 'selected' : ''); ?>>Izin</option>
                        <option value="cuti" <?php echo e(old('reason') == 'cuti' ? 'selected' : ''); ?>>Cuti</option>
                        <option value="dinas_luar" <?php echo e(old('reason') == 'dinas_luar' ? 'selected' : ''); ?>>Dinas Luar</option>
                        <option value="wfh" <?php echo e(old('reason') == 'wfh' ? 'selected' : ''); ?>>Work From Home</option>
                        <option value="lainnya" <?php echo e(old('reason') == 'lainnya' ? 'selected' : ''); ?>>Lainnya</option>
                    </select>
                    <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="description" class="font-weight-bold">
                        <i class="fas fa-align-left mr-1"></i>Keterangan Lengkap
                    </label>
                    <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                              name="description" 
                              id="description" 
                              rows="5"
                              placeholder="Jelaskan alasan konsesi secara detail (minimal 5 karakter)..."
                              required><?php echo e(old('description')); ?></textarea>
                    <small class="form-text text-muted">
                        Minimal 5 karakter
                    </small>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="start_date" class="font-weight-bold">
                                <i class="fas fa-calendar-day mr-1"></i>Tanggal Mulai
                            </label>
                            <input type="date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="start_date" id="start_date" 
                                   value="<?php echo e(old('start_date')); ?>"
                                   min="<?php echo e(date('Y-m-d')); ?>"
                                   required>
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="end_date" class="font-weight-bold">
                                <i class="fas fa-calendar-day mr-1"></i>Tanggal Selesai
                            </label>
                            <input type="date" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   name="end_date" id="end_date" 
                                   value="<?php echo e(old('end_date')); ?>"
                                   min="<?php echo e(date('Y-m-d')); ?>"
                                   required>
                            <small class="form-text text-muted">
                                Kosongkan jika hanya satu hari
                            </small>
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="status" class="font-weight-bold">
                        <i class="fas fa-check-circle mr-1"></i>Status
                    </label>
                    <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                            name="status" 
                            id="status"
                            required>
                        <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="approved" <?php echo e(old('status') == 'approved' ? 'selected' : ''); ?>>Disetujui</option>
                        <option value="rejected" <?php echo e(old('status') == 'rejected' ? 'selected' : ''); ?>>Ditolak</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <i class="fas fa-exclamation-triangle mr-1"></i><?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group mt-4">
                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fas fa-save mr-1"></i> Simpan Konsesi
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
.select2-container .select2-selection--single {
    height: 38px;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 36px;
}
.card {
    border: none;
    border-radius: 10px;
}
.btn {
    border-radius: 5px;
    padding: 10px 20px;
    font-weight: 500;
}
.btn-primary {
    background: linear-gradient(45deg, #007bff, #0056b3);
    border: none;
    transition: all 0.3s ease;
}
.btn-primary:hover {
    background: linear-gradient(45deg, #0056b3, #004085);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0, 123, 255, 0.3);
}
.btn-outline-primary {
    border: 2px solid #007bff;
    color: #007bff;
    transition: all 0.3s ease;
}
.btn-outline-primary:hover {
    background-color: #007bff;
    color: white;
    transform: translateY(-2px);
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Inisialisasi Select2
    $('.select2').select2({
        placeholder: "Pilih Pengguna",
        allowClear: true
    });
    
    // Validasi tanggal
    $('#start_date').change(function() {
        $('#end_date').attr('min', $(this).val());
        if ($('#end_date').val() && new Date($('#end_date').val()) < new Date($(this).val())) {
            $('#end_date').val($(this).val());
        }
    });

    // Character counter
    const description = document.getElementById('description');
    const charCounter = document.createElement('small');
    charCounter.className = 'form-text text-right text-muted float-right';
    description.parentNode.appendChild(charCounter);
    
    description.addEventListener('input', function() {
        charCounter.textContent = `${this.value.length} karakter`;
        if (this.value.length < 5) {
            charCounter.classList.add('text-danger');
            charCounter.classList.remove('text-success');
        } else {
            charCounter.classList.add('text-success');
            charCounter.classList.remove('text-danger');
        }
    });

    // Form submission handling
    $('#concessionForm').submit(function(e) {
        e.preventDefault();
        
        const form = $(this);
        const submitBtn = $('#submitBtn');
        
        submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Menyimpan...');
        
        $.ajax({
            url: form.attr('action'),
            method: 'POST',
            data: form.serialize(),
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if (response.success) {
                    // Tampilkan SweetAlert sukses
                    Swal.fire({
                        icon: 'success',
                        title: 'Sukses!',
                        text: response.message,
                        confirmButtonText: 'OK',
                        confirmButtonColor: '#007bff'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Redirect ke halaman daftar konsesi setelah klik OK
                            window.location.href = "<?php echo e(route('admin.concessions.index')); ?>";
                        }
                    });
                }
            },
            error: function(xhr) {
                let errorMessage = 'Terjadi kesalahan';
                
                if (xhr.responseJSON && xhr.responseJSON.errors) {
                    const errors = xhr.responseJSON.errors;
                    errorMessage = Object.values(errors)[0][0];
                } else if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }
                
                // Tampilkan SweetAlert error
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: errorMessage,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#dc3545'
                });
            },
            complete: function() {
                submitBtn.prop('disabled', false).html('<i class="fas fa-save mr-1"></i> Simpan Konsesi');
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\001 Aplikasi-Laravel\Absensi-Online\resources\views/admin/concession/create.blade.php ENDPATH**/ ?>